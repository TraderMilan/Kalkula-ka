public interface Calculation {

    default void result(){
    }


}
